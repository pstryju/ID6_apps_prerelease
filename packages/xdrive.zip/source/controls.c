/* Included by collector.c for Bootmod3 and xDrive controls. */
#ifdef BM3_ONLY
#include "bm3_profiles.h"

enum { BM3_MARKER_SIZE = 255 };

/* Binary markers captured upstream on 64/80-byte MG1 layouts and the G87 S58. */
static int bm3_match(const unsigned char *marker) {
    unsigned i, end, hash=0, hashes=0, binary=0, s58=0;
    int matched=-1;
    if (!memcmp(marker,"BM3_",4)) {
        static const unsigned delimiters[]={68,84};
        for (i=0;i<sizeof delimiters/sizeof delimiters[0];++i) {
            unsigned p=delimiters[i];
            if (memcmp(marker+p,"~|~_",4)) continue;
            p+=4;
            while (p<BM3_MARKER_SIZE && marker[p]=='_') ++p;
            if (p<BM3_MARKER_SIZE && marker[p]=='#') {
                if (binary) return -1;
                hash=p;
                binary=1;
            }
        }
        if (!binary) {
            for (i=0;i<BM3_MARKER_SIZE;++i) if (marker[i]=='#') { hash=i; ++hashes; }
            s58=hashes==1 && hash==101 && marker[hash+15]=='_';
        }
    }
    if (binary || s58) {
        for (end=hash+1;end<BM3_MARKER_SIZE && marker[end];++end) {
            unsigned c=marker[end];
            if (!(c>='A' && c<='Z') && !(c>='0' && c<='9') && !(s58 && c=='_')) return -1;
        }
        if (end==BM3_MARKER_SIZE || (s58 && end<hash+16)) return -1;
        if (s58) {
            for (i=hash+1;i<hash+15;++i) if (marker[i]=='_') return -1;
        }
        for (i=0;i<sizeof profiles/sizeof profiles[0];++i) {
            size_t size=strlen(profiles[i].rom);
            if (s58 ? size!=9 : end-hash-1!=size+5) continue;
            if (memcmp(marker+hash+1,profiles[i].rom,size)) continue;
            if (matched>=0) return -1;
            matched=(int)i;
        }
        return matched;
    }
    for (i=0;i+5<=BM3_MARKER_SIZE;++i) if (!memcmp(marker+i,"BM3_R",5)) break;
    if (i+5>BM3_MARKER_SIZE) return -1;
    for (i=0;i<sizeof profiles/sizeof profiles[0];++i) {
        const size_t size=strlen(profiles[i].rom);
        for (unsigned j=0;j+size+1<=BM3_MARKER_SIZE;++j) {
            if (marker[j]!='#' || memcmp(marker+j+1,profiles[i].rom,size) ||
                (j+size+1<BM3_MARKER_SIZE && isalnum(marker[j+size+1]))) continue;
            if (matched>=0 && matched!=(int)i) return -1;
            matched=(int)i;
        }
    }
    return matched;
}

static int bm3_profile(control_link fd) {
    const unsigned char define[]={0x2c,2,0xf3,1,0x24,0x80,0x7f,0xfe,0x50,0,BM3_MARKER_SIZE};
    const unsigned char defined[]={0x6c,2,0xf3,1}, read[]={0x22,0xf3,1}, prefix[]={0x62,0xf3,1};
    const unsigned char direct[]={0x23,0x14,0x80,0x7f,0xfe,0x50,BM3_MARKER_SIZE}, direct_ack[]={0x63};
    unsigned char reply[512];
    unsigned negative, offset=3;
    int n=exchange(fd,0x12,define,sizeof define,defined,sizeof defined,reply,sizeof reply,1600,&negative);
    if (n>=4) n=exchange(fd,0x12,read,sizeof read,prefix,sizeof prefix,reply,sizeof reply,1600,&negative);
    // The upstream direct read covers an unsupported dynamic DID, including issue #95's NRC 31.
    if (n==-2 && (negative==0x31 || negative==0x11 || negative==0x12)) {
        offset=1;
        n=exchange(fd,0x12,direct,sizeof direct,direct_ack,sizeof direct_ack,reply,sizeof reply,1600,&negative);
    }
    if (n!=(int)(offset+BM3_MARKER_SIZE)) {
        if (n==-2) printf("CustomROM identification refused (NRC %02X).\n",negative);
        else if (n<0) puts("No Bootmod3 CustomROM identification reply.");
        else puts("Unexpected Bootmod3 CustomROM identification layout.");
        return -1;
    }
    int matched=bm3_match(reply+offset);
    if (matched<0) puts("This Bootmod3 CustomROM is outside the supported profile list.");
    return matched;
}

static int write_memory(control_link fd, unsigned char sid, const unsigned char *address,
                       const unsigned char *bytes, unsigned size) {
    unsigned char req[31]={sid,0x14,address[0],address[1],address[2],address[3],(unsigned char)size};
    const unsigned char ack[]={ (unsigned char)(sid+0x40),0x3d };
    unsigned char reply[64];
    unsigned negative;
    memcpy(req+7,bytes,size);
    return exchange(fd,0x12,req,7+size,ack,sid==0x3e?2:1,reply,sizeof reply,1600,&negative)>0;
}

static int verify_memory(control_link fd, const unsigned char *address, const unsigned char *bytes, unsigned size) {
    const unsigned char req[]={0x23,0x14,address[0],address[1],address[2],address[3],(unsigned char)size};
    const unsigned char ack[]={0x63};
    unsigned char reply[32];
    unsigned negative;
    return exchange(fd,0x12,req,sizeof req,ack,sizeof ack,reply,sizeof reply,1600,&negative)==(int)size+1
           && !memcmp(reply+1,bytes,size);
}

/* Return the displayed slot (1–4), or zero when the ECU cannot report it. */
static unsigned current_map(control_link fd, const unsigned char *address, unsigned *negative) {
    const unsigned char req[]={0x23,0x14,address[0],address[1],address[2],address[3],1};
    const unsigned char ack[]={0x63};
    unsigned char reply[8];
    *negative=0;
    int n=exchange(fd,0x12,req,sizeof req,ack,sizeof ack,reply,sizeof reply,1600,negative);
    return n==2 && reply[1]<=3 ? (unsigned)reply[1]+1 : 0;
}

static void control(control_link fd, const char *mode, unsigned value) {
    unsigned char reply[512];
    unsigned negative;
    int profile=bm3_profile(fd), n;
    if (profile<0) return;
    if (!strcmp(mode,"--current-map")) {
        unsigned actual=current_map(fd,profiles[profile].map,&negative);
        if (actual) printf("Current map: %u\n",actual);
        else if (negative) printf("Current map read refused (NRC %02X).\n",negative);
        else puts("Current map unavailable.");
    } else if (!strcmp(mode,"--map") && value>=1 && value<=4) {
        const unsigned char *address=profiles[profile].map;
        const unsigned char command[]={ (unsigned char)(value-1),1 };
        int accepted=write_memory(fd,profiles[profile].sid,address,command,sizeof command);
        unsigned actual=current_map(fd,address,&negative);
        if (accepted && actual==value) printf("Map %u verified by DME readback.\n",actual);
        else if (actual) printf("Map %u change unconfirmed. Current map: %u.\n",value,actual);
        else puts("Map change unconfirmed. Current map unavailable.");
    } else if (!strcmp(mode,"--burbles") && value<=3) {
        const unsigned char sid=profiles[profile].sid;
        const unsigned char *enable=profiles[profile].enable, *timing=profiles[profile].timing;
        const unsigned factor=profiles[profile].factor;
        const unsigned char enabled=value!=0;
        unsigned char table[24];
        if ((!enable[0] && !enable[1] && !enable[2] && !enable[3]) ||
            (!timing[0] && !timing[1] && !timing[2] && !timing[3]) || !factor || 12*factor>127) {
            puts("Burble preset unavailable for this ROM.");
            return;
        }
        memset(table,(unsigned char)(0u-value*4*factor),sizeof table);
        if ((!value && !write_memory(fd,sid,enable,&enabled,1)) ||
            !write_memory(fd,sid,timing,table,sizeof table) ||
            (value && !write_memory(fd,sid,enable,&enabled,1)) ||
            !verify_memory(fd,timing,table,sizeof table) || !verify_memory(fd,enable,&enabled,1)) {
            puts("Burble request incomplete or unconfirmed.");
            return;
        }
        if (value) printf("Burble preset %u verified by DME readback.\n",value*4);
        else puts("Burbles off, verified by DME readback.");
    } else if (!strcmp(mode,"--flap") && value<=2) {
        const unsigned char req[]={0x2f,0x60,0xfd,value?3:0,value==1?0x14:0x23,value==1?0xfe:0x28};
        const unsigned char ack[]={0x6f,0x60,0xfd,req[3]};
        n=exchange(fd,0x12,req,value?6:4,ack,sizeof ack,reply,sizeof reply,1600,&negative);
        if (n>=4) puts("Exhaust flap request accepted by DME.");
        else puts("Exhaust flap request could not be confirmed.");
    } else if (!strcmp(mode,"--sound") && value<=1) {
        const unsigned char req[]={0x2e,0x5f,0xfd,value?0:1}, ack[]={0x6e,0x5f,0xfd};
        n=exchange(fd,0x12,req,sizeof req,ack,sizeof ack,reply,sizeof reply,1600,&negative);
        if (n>=3) puts("Active Sound request accepted by DME.");
        else puts("Active Sound request could not be confirmed.");
    }
}
#else
static int read_mode(int fd) {
    const unsigned char req[]={0x22,0xdb,0x32}, ack[]={0x62,0xdb,0x32};
    unsigned char reply[64];
    unsigned negative;
    const int n=exchange(fd,0x19,req,sizeof req,ack,sizeof ack,reply,sizeof reply,800,&negative);
    if (n<11) return -1;
    if ((reply[10]&0xc0)==0xc0) return 0;
    if (reply[10]==0x20 || reply[10]==0x21) return 1;
    return -1;
}

// F-series LMV 0F1480 (lmv_01.prg STATUS_SOLLMOMENT, 0x4002): byte 3 is the target qualifier.
// 0x20 applies the DSC target (AWD); 0x28 opens the clutch and 0x70 is rear-wheel drive.
// With the engine off it reports 0x60 (fallback), so the mode is only readable while running.
static unsigned read_sgbd(int fd, unsigned ecu, int *length, unsigned *negative) {
    const unsigned char req[]={0x22,0xf1,0x50}, prefix[]={0x62,0xf1,0x50};
    unsigned char reply[16];
    int n=exchange(fd,ecu,req,sizeof req,prefix,sizeof prefix,reply,sizeof reply,800,negative);
    if (length) *length=n;
    if (n<6 || n>10) return 0;
    for (int i=3;i<n-3;++i) if (reply[i]) return 0;
    return (unsigned)reply[n-3]<<16 | (unsigned)reply[n-2]<<8 | reply[n-1];
}

static int lmv_mode(int fd) {
    const unsigned char req[]={0x22,0x40,0x02}, ack[]={0x62,0x40,0x02};
    unsigned char reply[64];
    unsigned negative;
    if (exchange(fd,0x19,req,3,ack,3,reply,sizeof reply,800,&negative)<6) return -1;
    if (reply[5]==0x20) return 1;
    if (reply[5]==0x28 || reply[5]==0x70) return 0;
    return -1;
}

static int parked(int fd, int running) {
    const unsigned char speed[]={1,0x0d}, speed_ack[]={0x41,0x0d};
    const unsigned char gear[]={0x22,0xda,0x2e}, gear_ack[]={0x62,0xda,0x2e};
    const unsigned char rpm[]={1,0x0c}, rpm_ack[]={0x41,0x0c};
    unsigned char reply[8];
    unsigned negative;
    // Same Park read as the 340i parked probe. Missing or different replies block the write.
    return exchange(fd,0x18,gear,3,gear_ack,3,reply,sizeof reply,350,&negative)==5 && reply[3]==0 && reply[4]==6 &&
           exchange(fd,0x12,rpm,2,rpm_ack,2,reply,sizeof reply,350,&negative)==4 && ((reply[2]|reply[3])!=0)==running &&
           exchange(fd,0x12,speed,2,speed_ack,2,reply,sizeof reply,350,&negative)==3 && !reply[2];
}

static void control(int fd, const char *mode, unsigned value) {
    const unsigned char capability[]={0x22,0xdb,0xe1}, cap_ack[]={0x62,0xdb,0xe1};
    unsigned char reply[64];
    unsigned negative;
    int n, current, fseries;
    const unsigned index=read_sgbd(fd,0x29,&n,&negative);
    if (n == -2) { printf("DSC identification refused (NRC %02X).\n",negative); return; }
    if (n < 0) { puts("No DSC reply at 0x29. Check the diagnostic gateway."); return; }
    if (!index) { puts("DSC replied with an unrecognized identification format."); return; }
    if (index!=0x0f2510 && index!=0x0f2850 && index!=0x0f1860) {
        if (!strcmp(mode,"--status")) {
            const unsigned lmv=read_sgbd(fd,0x19,0,&negative);
            const unsigned vip=read_sgbd(fd,0x39,0,&negative);
            char lmv_id[12]="unknown", vip_id[12]="unknown";
            if (lmv) snprintf(lmv_id,sizeof lmv_id,"%06X",lmv);
            if (vip) snprintf(vip_id,sizeof vip_id,"%06X",vip);
            printf("Unsupported DSC %06X. Transfer case %s. VIP %s.\n",index,lmv_id,vip_id);
        } else printf("DSC %06X is outside the supported control list.\n",index);
        return;
    }
    n=exchange(fd,0x29,capability,3,cap_ack,3,reply,sizeof reply,800,&negative);
    if (n<4) {
        if (n==-2) printf("DSC mode read refused (NRC %02X).\n",negative);
        else puts("DSC mode read unavailable.");
        return;
    }
    // DSC_25 (F-series) drops LMV control with the engine off, so it switches with the engine running.
    fseries=index==0x0f1860;
    if (fseries && read_sgbd(fd,0x19,0,&negative)!=0x0f1480) {
        puts("DSC_25 requires a verified LMV 0F1480 transfer case.");
        return;
    }
    current=fseries ? lmv_mode(fd) : read_mode(fd);
    if (!strcmp(mode,"--status")) {
        puts(current<0 ? (fseries?"Start the engine to read the transfer case.":"Transfer case mode unavailable.") :
             current?"Transfer case reports AWD.":"Transfer case reports RWD.");
        return;
    }
    // dsc_25.prg documents DBE1 as writable with 1 = active; restore verified on a 0F1860 car.
    if (value && index!=0x0f2850 && !fseries) { puts("Cycle the ignition to restore AWD on this DSC."); return; }
    if (current<0) { puts(fseries?"Start the engine to read the transfer case.":"Transfer case mode unavailable."); return; }
    if (!parked(fd,fseries)) {
        puts(fseries?"Needs engine running, stationary, and confirmed Park.":"Needs ignition on, engine off, stationary, and confirmed Park.");
        return;
    }
    {
        const unsigned char request[]={0x2e,0xdb,0xe1,(unsigned char)value}, ack[]={0x6e,0xdb,0xe1};
        const struct timespec pause={0,250000000};
        n=exchange(fd,0x29,request,4,ack,3,reply,sizeof reply,2400,&negative);
        if (n==-2) { printf("DSC refused this request (NRC %02X).\n",negative); return; }
        // DSC_25 acknowledged after more than 2 s on the car, so read back even without an ack.
        const uint64_t deadline=bd_mono_ms()+2000;
        while (bd_mono_ms()<deadline) {
            current=fseries ? lmv_mode(fd) : read_mode(fd);
            if (current==(int)value) break;
            nanosleep(&pause,0);
        }
        if (current==(int)value) puts(value?"Transfer case confirms AWD.":"Transfer case confirms RWD.");
        else puts(n>=3?"DSC accepted. Transfer case mode is unconfirmed.":"DSC request could not be confirmed.");
    }
}
#endif

int main(int argc,char **argv) {
    unsigned value, port=6801;
#ifndef BM3_ONLY
    int fd,lock;
#endif
    if ((argc!=5 && argc!=7) || strcmp(argv[1],"--host")) return 2;
    if (argc==7) {
        if (strcmp(argv[5],"--port")) return 2;
        port=number(argv[6],1,65535);
    }
#ifdef BM3_ONLY
    if (strcmp(argv[3],"--current-map") && strcmp(argv[3],"--map") && strcmp(argv[3],"--flap") && strcmp(argv[3],"--sound") && strcmp(argv[3],"--burbles")) return 2;
#else
    if (strcmp(argv[3],"--status") && strcmp(argv[3],"--drive-mode")) return 2;
#endif
    value=number(argv[4],0,!strcmp(argv[3],"--map") ? 4 : !strcmp(argv[3],"--flap") ? 2 : !strcmp(argv[3],"--burbles") ? 3 : 1);
    if (!strcmp(argv[3],"--map") && !value) return 2;
#ifdef BM3_ONLY
    struct diag_link link;
    struct diag_link_cfg cfg;
    const int burbles = !strcmp(argv[3], "--burbles");
    diag_link_signals();
    memset(&cfg, 0, sizeof cfg);
    cfg.host = argv[2];
    cfg.port = port;
    cfg.transport = burbles ? DIAG_HSFZ : DIAG_AUTO;
    cfg.kind = DIAG_ONESHOT;
    cfg.dsi_name = "bootmod3";
    diag_link_init(&link, &cfg);
    if (!diag_link_reserve_oneshot(&link)) {
        puts("Diagnostics busy. Try again.");
        return 0;
    }
    if (diag_link_up(&link)) control(&link, argv[3], value);
    else if (burbles) puts("Burble presets require the HSFZ gateway.");
    else puts("Diagnostic gateway unavailable.");
    diag_link_close(&link);
#else
    signal(SIGINT,stop); signal(SIGTERM,stop); signal(SIGPIPE,SIG_IGN);
    lock=reserve_gateway();
    if (lock<0) { puts("Diagnostics busy. Try again."); return 0; }
    fd=connect_gw(argv[2],port);
    if (fd>=0) { control(fd,argv[3],value); close(fd); }
    else puts("Diagnostic gateway unavailable.");
    close(lock);
#endif
    return 0;
}
