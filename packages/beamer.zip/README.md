# BEAMer for iDrive 6

Front, Rear, Both, and Insane run in Park at zero speed. Tested on an F3x car. Other Fxx cars may work if they have the supported lighting module. Gxx has not been tested. Requires a 1280 x 480 display. Verify firmware and framework compatibility before installing. Open My Vehicle > BEAMer.

## Package update

A reachable HSFZ gateway and the supported lighting module are required.

Install the selected app folders under /var/opt/hmi/data/ID5/Plugins on the HMI node. Verify compatibility and set executable permissions on the -qnx worker before a parked restart. A verified IPv4 address in /var/opt/hmi/data/ID5/gateway-ip.txt overrides per-app settings. Setup instructions are in the repository AgentReadMe.
