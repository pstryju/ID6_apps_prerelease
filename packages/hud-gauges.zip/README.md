# HUD Gauges

See the GitHub repository's AgentReadMe.md for compatibility and deployment. This package targets the tested NBTevo_N18032I reference 340i with the corresponding factory windshield HUD and diagnostic gateway. Install the HudTest folder only, permit the QNX worker to execute, and restart iDrive after verifying the uploaded files.

Open My Vehicle → HUD Gauges and check Show HUD gauges. The live tach spans 0–8,000 RPM and the thicker redline zone starts at 6,700 RPM. Boost is a numeric PSI readout. The checkbox persists across boots and can be unchecked to clear the overlay. Validate the overlay while parked before use.

## Package update

The worker accepts a verified gateway IPv4 address. The packaged overlay uses the reference HUD layout. Other layouts require separate verification.

Install the selected app folders under /var/opt/hmi/data/ID5/Plugins on the HMI node. Verify compatibility and set executable permissions on the -qnx worker before a parked restart. A verified IPv4 address in /var/opt/hmi/data/ID5/gateway-ip.txt overrides per-app settings. Setup instructions are in the repository AgentReadMe.
