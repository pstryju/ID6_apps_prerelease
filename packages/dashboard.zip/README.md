# Dashboard package

The dashboard includes BoostDeck, ShiftDeck, Engine Fault Codes and MHD+ Suite. Open Options in MHD+ Suite for Exhaust Flap or Max Cooling.

The dashboard workers use HSFZ with MOST fallback. Exhaust Flap uses its bundled HSFZ worker. Set the diagnostic gateway per app in gateway-ip.txt. See AgentReadMe.md in the repository for install and migration steps.
