# Dashboard package

The dashboard includes BoostDeck, ShiftDeck, Engine Fault Codes and MHD+ Suite. Open Options in MHD+ Suite for Exhaust Flap or Max Cooling.

The dashboard workers use HSFZ with MOST fallback. The dedicated Exhaust Flap worker also falls back to MOST. Set the diagnostic gateway per app in gateway-ip.txt. See AgentReadMe.md in the repository for install and migration steps.

BoostDeck saves its color and units. ShiftDeck saves its shift-light RPM and units. Preferences are stored outside the plugin folders so app updates preserve them.

## Package update

BoostDeck OPTIONS configures all nine original gauge positions and selects a separate diesel layout. MHD+ Suite displays the last map and Max Cooling choices acknowledged by the DME.

Install the selected app folders under /var/opt/hmi/data/ID5/Plugins on the HMI node. Verify compatibility and set executable permissions on the -qnx worker before a parked restart. A verified IPv4 address in /var/opt/hmi/data/ID5/gateway-ip.txt overrides per-app settings. Setup instructions are in the repository AgentReadMe.
